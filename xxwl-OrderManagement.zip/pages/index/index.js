//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: '欢迎使用本程序',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    industry: ["服装生产", "more"],
    index: 0,
    isAdmin: false,
  },

  //* 长按motto，用于测试
  bindViewTap: function() {
    if (this.data.hasUserInfo == false) {
      return
    }
    var that = this
    wx.showActionSheet({
      itemList: ['注册账户（废弃）', '登录账户（废弃）', '重新登录', '查看启动日志'],
      success: function(res) {
        var i = res.tapIndex
        //用检查缓存的方式，查询是否已经用户登录(user_id非空)
        var user_id
        try {
          user_id = wx.getStorageSync('user_id')
        } catch (e) {
          user_id = ""
        }
        //注册账户
        if (i == 0) {
          if (user_id != '') //该用户已经注册过了
          {
            that.askReLogIn(0)
          } else { //没有注册过，进入注册页面
            wx.navigateTo({
              url: '../register/register'
            })
          }
        }
        //登录账户
        else if (i == 1) {
          if (user_id != '') //该用户已经登录
          {
            that.askReLogIn(1)
          } else { //没有注册过，进入登录页面
            wx.navigateTo({
              url: '../login/login'
            })
          }
        }
        //调整角色类型（测试用）
        else if (i == 2) {
          that.setData({
            hasUserInfo: false,
            userInfo: {},
            isAdmin: false,
            motto: '欢迎使用本程序',
          })
          // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
          // 所以此处加入 callback 以防止这种情况
          app.userInfoReadyCallback = res => {
            this.setData({
              userInfo: res.userInfo,
              hasUserInfo: true,
            })
            //跳转页面（测试版）
            // var role_number = wx.getStorageSync('role_number')
            // this.testTo(role_number)
          }
          // wx.showActionSheet({
          //   itemList: ['客户', '录单员', '员工', '管理员'],
          //   success: function(res) {
          //     that.changeRole(res.tapIndex)
          //   }
          // })
        }
        //查看启动日志（测试用）
        else if (i == 3) {
          wx.navigateTo({
            url: '../logs/logs'
          })
        }
      },
      fail: function(res) {
        //console.log(res.errMsg)
      }
    })
    // 7/31 网络请求
    wx.request({
      url: 'http://140.143.154.96/day07/loginServlet',
      data: {},
      header: {
        'content-type': 'application/json'
      },
      success: function(res) {
        console.log(res)
      }
    })
  },

  //于7/28弃用 询问是否注销、重新注册（0）或登录（1）
  askReLogIn: function(i) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '您已拥有账户，并已经处于登录的状态。是否注销？',
      success: function(res) {
        //用户点击确定，清空user_id及相关缓存（表示注销）
        if (res.confirm) {
          wx.setStorageSync('user_id', '')
          wx.removeStorageSync('user_name')
          wx.setStorageSync('role_number', '')
          that.setData({
            motto: '您的身份：游客'
          })
          if (i == 0) { //注册
            wx.navigateTo({
              url: '../register/register'
            })
          } else if (i == 1) { //登录
            wx.navigateTo({
              url: '../login/login'
            })
          }
        }
      }
    })
  },

  //* 页面显示
  onShow: function() {
    var that = this
    //获取并修改role（角色）信息
    try {
      var value = wx.getStorageSync('role_number')
      if (value != "") {
        that.changeRole(value)
      }
    } catch (e) {
      // Do something when catch error
    }
  },

  //* 页面加载
  onLoad: function() {
    if (app.globalData.userInfo) {
      this.setData({
        // 弃用头像的显示 userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true,
        })
        //延迟1000ms后跳页面，防止读取role_number时它还没有写入缓存
        // setTimeout(function() {
        //  try {
        //     var role_number = wx.getStorageSync('role_number')
        //     console.log(role_number)
        //     this.testTo(role_number) //todo:测试完改回goTo
        //  } catch (e) {
        //   console.log('读取role_number失败')
        //   }
        // }.bind(this), 1000)
      }
    }
  },

  getUserInfo: function(e) {
    var that = this
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
    // 改于7/28 询问用户角色（用于测试）
    //实际情况下，调用数据库查询来获取角色信息
    wx.showActionSheet({
      itemList: ['客户', '录单员', '员工', '管理员'],
      success: function(res) {
        var i = res.tapIndex
        that.changeRole(i)
        //如果身份非管理员，直接进入可操作的页面
        if (i != 3) {
          that.testTo(i)//todo:测试完改回goTo
        }
      }
    })
  },

  //根据身份不同，跳转页面
  goTo: function(i) {
    if (i == 2) {
      wx.redirectTo({
        url: '/pages/operate/operate'
      })
    } else if (i == 1) {
      wx.redirectTo({
        url: '/pages/input/input'
      })
    } else if (i == 0) {
      wx.redirectTo({
        url: '/pages/inquiry/inquiry'
      })
    }
  },

  //根据身份不同，跳转页面（测试版）
  testTo: function(i) {
    if (i == 2) {
      wx.navigateTo({
        url: '/pages/operate/operate'
      })
    } else if (i == 1) {
      wx.navigateTo({
        url: '/pages/input/input'
      })
    } else if (i == 0) {
      wx.navigateTo({
        url: '/pages/inquiry/inquiry'
      })
    }
  },

  //改变使用者的role（角色）-------------------
  //客户对应0，可以订单查询、进度查询
  //录单员对应1，可以录入订单
  //员工对应数字2，可以进行工单操作
  //管理员对应数字3，可以进行所有操作
  changeRole: function(i) {
    //修改缓存
    try {
      wx.setStorageSync('role_number', i)
    } catch (e) {}
    //判断角色，设置TabBar
    var role
    if (i == 2) {
      role = '员工'
    } else if (i == 0) {
      role = '客户'
    } else if (i == 1) {
      role = '录单员'
    }
    // 7/28 增加管理员身份
    else if (i == 3) {
      role = '管理员'
      //设置TabBar
      var myTabBar = app.globalData.tabBar
      myTabBar.list[0].active = true
      myTabBar.list[1].active = false
      myTabBar.list[2].active = false
      myTabBar.list[3].active = false
      this.setData({
        isAdmin: true,
        tabBar: myTabBar
      })
    }
    //设置motto的内容
    var str = '您的身份：' + role
    this.setData({
      motto: str,
    })
  },

  // 7/28  选择行业
  bindPickerChange: function(e) {
    this.setData({
      index: e.detail.value
    })
  },

  //转发
  onShareAppMessage: function(res) {

  }

})