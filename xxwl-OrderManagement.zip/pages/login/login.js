// pages/login/login.js

var data = require('../../utils/data.js')

Page({

  data: {
    label0: '用户类型',
    label1: '用户账号',
    label2: '用户密码',
    index: 2,
    role_type: ['用户', '管理者', '员工'],
    inputValue1: '',
    inputValue2: '',
  },

  bindKeyInput1: function(e) {
    this.setData({
      inputValue1: e.detail.value
    })
  },

  bindKeyInput2: function(e) {
    this.setData({
      inputValue2: e.detail.value
    })
  },

  //点击确认按钮
  onConfirm: function() {
    var that = this
    var prompt
    var name = this.data.inputValue1
    var passwd = this.data.inputValue2
    //todo:将name passwd放到数据库中查询，返回结果写进prompt
    //如果prompt非空，说明输入有误
    if (prompt) {
      wx.showModal({
        title: '提示',
        content: prompt,
        showCancel: false
      })
    }
    //输入符合要求，回到index页面
    else {
      this.doLogIn(name, passwd)
      // wx.switchTab({
      //   url: '/pages/index/index'
      // })
      wx.redirectTo({
        url: '/pages/index/index',
      })
    }
  },

  //登录
  doLogIn: function(user_name, pass_word) {
    //查询用户信息
    //这里在data.js中查询user_id
    var users = data.user
    var len = users.length
    var i
    for (i = 0; i < len; i++) {
      if (users[i].user_name == user_name) {
        break
      }
    }
    var user_id = users[i].user_id
    var role_number = this.getRoleNumber(users[i].role_type)
    //修改缓存
    wx.setStorageSync('user_name', user_name)
    wx.setStorageSync('user_id', user_id)
    wx.setStorageSync('role_number', parseInt(role_number))
  },

  //根据role_type得到role_number
  getRoleNumber: function(str) {
    if (str == '客户') {
      return 0
    } else if (str == '管理者') {
      return 1
    } else if (str == '员工') {
      return 2
    }
  }

})