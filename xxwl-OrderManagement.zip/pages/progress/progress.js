// pages/progress/progress.js

var data = require('../../utils/data.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    receipt_type: ['类型1', '类型2', '类型3', '类型4', '类型5'],
    index_type: 0,
    receipt_name: ['女装T恤中长款', '修身款圆领男T恤', '休闲t恤女', '男运动上衣', '时尚女t恤'],
    index_name: 0,
    processData: [],
  },

  //根据user_id和用户表查询user_name
  getUserName: function (user_id) {
    var users = data.user
    var len = users.length
    for (var i = 0; i < len; i++) {
      if (users[i].user_id == user_id) {
        return users[i].user_name
      }
    }
  },

  //根据job_table，设置进度条数据
  setProcessData: function (jobs) {
    var data = []
    var len = jobs.length
    for (var i = 0; i < len; i++) {
      var job = jobs[i]
      //var user_name = this.getUserName(job.user_id)
      //如果已处理
      if (job.status == "已处理") {
        data[i] = {
          name: job.name,
          user_name: job.user_name,
          time_date: this.getDate(job.time),
          time_hour:this.getHour(job.time),
          line_color: "#bfbfbf",
          font_color: "#2c2c2c",
          icon: '/imgs/check-circle.png',
          state: '已处理',
          note: job.note
        }
      }
      //如果正在处理
      else if (job.button == '完工') {
        data[i] = {
          name: job.name,
          user_name: job.user_name,
          time_date: this.getDate(job.time),
          time_hour: this.getHour(job.time),
          line_color: "#e6e6e6",
          font_color: "#2c2c2c",
          icon: '/imgs/time-circle.png',
          state: '正在处理'
        }
      }
      //如果还没处理
      else {
        data[i] = {
          name: job.name,
          line_color: "#e6e6e6",
          font_color: "#e6e6e6",
          icon: '/imgs/undo-circle.png'
        }
      }
    }
    data[len - 1].line_color = "#ffffff"
    this.setData({
      processData: data,
    })
  },

  // 弃用 选择了订单类型
  // bindPickerChangeT: function (e) {
  //   this.setData({
  //     index_type: e.detail.value
  //   })
  // },

  // 弃用 选择了订单名称
  // bindPickerChangeN: function (e) {
  //   this.setData({
  //     index_name: e.detail.value
  //   })
  // },

  //* 生命周期函数--监听页面显示
  onShow: function () {
    var r_number = wx.getStorageSync('r_number')
    //获取r_number订单的工单表数据，
    //这里引用data.js中的operation来代替。
    //使用工单表数据修改页面中的processData数据：
    this.setProcessData(data.operation)
  },

  //time字符串处理
  simpTime: function (time) {
    return time.slice(5, 16)
  },
  getDate: function (time) {
    return time.slice(5, 10)
  },
  getHour: function (time) {
    return time.slice(11, 16)
  },

  //生命周期函数--监听页面加载
  onLoad: function (options) {
  },

  //转发
  onShareAppMessage: function (res) {

  }
  
})