// pages/inquiry/inquiry.js

var data = require('../../utils/data.js')

Page({

  data: {
    titles: [{
        name: '已完成',
        color_b: '#F8F8F8',
        color_f: '#9E9E9E'
      },
      {
        name: '未完成',
        color_b: '#F8F8F8',
        color_f: '#9E9E9E'
      }
    ],
    index: 0,
    receipt: [],
    isAdmin: false,
  },

  //* 点击“已完成”或“未完成”
  changeTit: function(event) {
    var name = event.currentTarget.dataset.name
    if (name == "未完成") {
      this.changeTitWXSS(1)
    } else if (name == "已完成") {
      this.changeTitWXSS(0)
    }
    this.setReceipts()
  },

  //改变titles数据的WXML标签样式
  changeTitWXSS: function(i) {
    var str1 = 'titles[' + i + '].color_b'
    var str2 = 'titles[' + i + '].color_f'
    var that = this
    that.setData({
      [str1]: '#FFF',
      [str2]: '#000',
    })
    var old_i = that.data.index
    if (i != old_i) {
      str1 = 'titles[' + old_i + '].color_b'
      str2 = 'titles[' + old_i + '].color_f'
      that.setData({
        [str1]: '#F8F8F8',
        [str2]: '#9E9E9E',
        index: i,
      })
    }
  },

  //遍历receipt数组，根据index的值，设置数据是否隐藏
  setReceipts: function() {
    var index = this.data.index
    var rcps = this.data.receipt
    var len = rcps.length
    for (var i = 0; i < len; i++) {
      var status = rcps[i].r_state
      if (status == "已完成") {
        if (index == 0) {
          this.changeHidden(i, false)
        } else {
          this.changeHidden(i, true)
        }
      } else {
        if (index == 1) {
          this.changeHidden(i, false)
        } else {
          this.changeHidden(i, true)
        }
      }
    }
  },

  //改变receipt数组第i个数据的hidden属性为bool
  changeHidden: function(i, bool) {
    var str = 'receipt[' + i + '].hidden'
    this.setData({
      [str]: bool
    })
  },

  //设置data中的receipt数组
  setRecptData: function() {
    //数据库操作：查询用户所关心的订单列表
    //这里使用data.js的数据代替
    var proRecpts = data.receipt
    var len = proRecpts.length
    var recpt = {
      r_number: "",
      r_img: "",
      r_name: "",
      r_type: "",
      r_state: "",
      hidden: false
    }
    for (var i = 0; i < len; i++) {
      var proRecpt = proRecpts[i]
      recpt.r_number = proRecpt.receipt_number
      recpt.r_img = proRecpt.img
      recpt.r_name = proRecpt.name
      recpt.r_type = proRecpt.receipt_type
      recpt.r_state = proRecpt.state
      var str = 'receipt[' + i + ']'
      this.setData({
        [str]: recpt
      })
    }
  },

  //* 订单号查询(todo)
  inquiryNum: function() {
    wx.showToast({
      title: '功能尚未开发',
      icon: 'loading',
      duration: 1000
    })
  },

  //* 点击“查看进度”
  inquiry: function(event) {
    var r_number = event.currentTarget.dataset.num
    //将查询的r_number写入缓存
    wx.setStorageSync('r_number', r_number)
    //根据r_number检索数据在receipt数组中的位置，播放动画
    var recpts = this.data.receipt
    var len = recpts.length
    for (var i = 0; i < len; i++) {
      var recpt = recpts[i]
      if (recpt.r_number == r_number) {
        this.playAnima(i)
      }
    }
    //延迟300ms后跳页面
    setTimeout(function() {
      wx.navigateTo({
        url: '../progress/progress'
      })
    }.bind(this), 300)
  },

  //播放动画
  playAnima: function(i) {
    var str = 'receipt[' + i + '].animaData'
    var animation = wx.createAnimation({
      duration: 200,
    })
    this.animation = animation
    //缩小
    animation.scale(0.7, 0.7).step()
    this.setData({
      [str]: animation.export()
    })
    //放大
    setTimeout(function() {
      animation.scale(1, 1).step({
        duration: 100
      })
      this.setData({
        [str]: animation.export()
      })
    }.bind(this), 200)
  },

  //* 生命周期函数--监听页面显示
  onShow: function() {
    //判断用户身份是否为管理员
    try {
      var value = wx.getStorageSync('role_number')
      if (value == 3) { //是管理员
        //设置tabBar
        var myTabBar = getApp().globalData.tabBar
        myTabBar.list[0].active = false
        myTabBar.list[1].active = false
        myTabBar.list[2].active = true
        myTabBar.list[3].active = false
        this.setData({
          tabBar: myTabBar,
          isAdmin: true
        })
      }
    } catch (e) {
      // Do something when catch error
    }
    //设置数据
    this.setRecptData()

  },

  //* 生命周期函数--监听页面加载
  onLoad: function(options) {
    //切换到"未完成"页
    this.changeTitWXSS(1)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})