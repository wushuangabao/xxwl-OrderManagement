// pages/operate/operate.js

var util = require('../../utils/util.js')
var data = require('../../utils/data.js')
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    titles: [{
        name: '已完成',
        color_b: '#F8F8F8',
        color_f: '#9E9E9E'
      },
      {
        name: '待分配',
        color_b: '#F8F8F8',
        color_f: '#9E9E9E'
      },
      {
        name: '未完成',
        color_b: '#F8F8F8',
        color_f: '#9E9E9E'
      }
    ],
    index: 0,
    operation: data.operation,
    isAdmin: false,
    note: '',
  },

  //* 点击“领取”或“完工”按钮
  onTapButton: function(event) {
    var job_number = event.currentTarget.dataset.number
    var operations = this.data.operation
    var len = operations.length
    //根据job_number检索数据在operation数组中的位置
    for (var i = 0; i < len; i++) {
      var operation = operations[i]
      if (operation.job_number == job_number) {
        if (operation.button == '领取') {
          this.setButton(i, false)
          this.playAnima(i)
          setTimeout(function() {
            this.changeTitWXSS(2)
            this.setOperations()
          }.bind(this), 300)
        } else if (operation.button == '完工') {
          this.setButton(i, true)
          this.playAnima(i)
          setTimeout(function() {
            this.changeTitWXSS(0)
            this.setOperations()
          }.bind(this), 300)
        }
        break
      }
    }
  },

  //设置第i条工序的备注
  setNote: function(i,note) {
    if (note != '') {
      var str = 'operation[' + i + '].note'
      this.setData({
        [str]: note
      })
    }
  },

  //播放动画
  playAnima: function(i) {
    var str = 'operation[' + i + '].animaData'
    var animation = wx.createAnimation({
      duration: 200, //缩小动画的持续时间
    })
    this.animation = animation
    setTimeout(function() {
      animation.scale(0.25, 0.25).rotate(30).step()
      this.setData({
        [str]: animation.export()
      })
    }.bind(this), 100) //缩小动画播放的延迟时间
    setTimeout(function() {
      animation.scale(1, 1).rotate(0).step({
        duration: 200
      })
      this.setData({
        [str]: animation.export()
      })
    }.bind(this), 500) //恢复原来大小的动画
  },

  //根据按下的button，设置operation的状态数据，增加对应的user、time数据。
  setButton: function(i, bool) {
    var that = this
    var time = util.formatTime(new Date())
    //bool为false表示该操作未领取。
    if (bool == false) {
      var str1 = 'operation[' + i + '].button'
      var str2 = 'operation[' + i + '].hid_button' //隐藏button，防止误点第二下
      var str3 = 'operation[' + i + '].user_name'
      var str4 = 'operation[' + i + '].time'
      var user_name = app.globalData.userInfo.nickName
      that.setData({
        [str1]: '完工',
        [str2]: true,
        [str3]: user_name,
        [str4]: util.formatTime(new Date()),
      })
      //修改数据库
      //暂时用修改data.js来代替
      data.operation[i].time = time
      data.operation[i].button = '完工'
      data.operation[i].user_id = wx.getStorageSync('user_id')
      data.operation[i].user_name = user_name
      //等待600ms后动画播放完毕，再显示button
      setTimeout(function() {
        that.setData({
          [str2]: false,
        })
      }.bind(this), 600)
    }
    //bool为true表示该操作已领取。
    else {
      var str1 = 'operation[' + i + '].status'
      var str2 = 'operation[' + i + '].time' //完工时，修改time，由领取时的时间，变为完工时的时间
      that.setData({
        [str1]: '已处理',
        [str2]: time,
      })
      //修改数据库
      //暂时用修改data.js来代替
      data.operation[i].status = '已处理'
      data.operation[i].time = time
      data.operation[i].note = that.data.operation[i].note
    }
  },

  //* 点击“已完成”、“待分配”或“未完成”
  changeTit: function(event) {
    var name = event.currentTarget.dataset.name
    if (name == "待分配") {
      this.changeTitWXSS(1)
    } else if (name == "未完成") {
      this.changeTitWXSS(2)
    } else if (name == "已完成") {
      this.changeTitWXSS(0)
    }
    this.setOperations()
  },

  //改变titles数据的WXML标签样式
  changeTitWXSS: function(i) {
    var str1 = 'titles[' + i + '].color_b'
    var str2 = 'titles[' + i + '].color_f'
    var that = this
    that.setData({
      [str1]: '#FFF',
      [str2]: '#000',
    })
    var old_i = that.data.index
    if (i != old_i) {
      str1 = 'titles[' + old_i + '].color_b'
      str2 = 'titles[' + old_i + '].color_f'
      that.setData({
        [str1]: '#F8F8F8',
        [str2]: '#9E9E9E',
        index: i,
      })
    }
  },

  //改变operation数组第i个数据的hidden属性为bool
  changeHidden: function(i, bool) {
    var str = 'operation[' + i + '].hidden'
    this.setData({
      [str]: bool
    })
  },

  //遍历operation数组，根据index的值，设置数据是否隐藏
  setOperations: function() {
    var index = this.data.index
    var operations = this.data.operation
    var len = operations.length
    for (var i = 0; i < len; i++) {
      var status = operations[i].status
      if (status == "已处理") {
        if (index == 0) {
          this.changeHidden(i, false)
        } else {
          this.changeHidden(i, true)
        }
      } else if (status == "未处理") {
        var button = operations[i].button
        if (button == "领取") {
          if (index == 1) {
            this.changeHidden(i, false)
          } else {
            this.changeHidden(i, true)
          }
        } else if (button == "完工") {
          if (index == 2) {
            this.changeHidden(i, false)
          } else {
            this.changeHidden(i, true)
          }
        }
      }
    }
  },

  //给operation数组数据赋新的属性hid_button、hidden和button
  setNewButton: function() {
    var operations = this.data.operation
    var len = operations.length
    var str1
    var str2
    for (var i = 0; i < len; i++) {
      str1 = 'operation[' + i + '].hid_button' //隐藏button
      str2 = 'operation[' + i + '].hidden' //隐藏整个item
      this.setData({
        [str1]: false,
        [str2]: false,
      })
      var the_operation = operations[i]
      //如果status是"未处理"，添加button
      if (the_operation.status == '未处理') {
        var text_on_button
        if (the_operation.button == '完工') {
          text_on_button = '完工'
        } else {
          text_on_button = '领取'
        }
        str1 = 'operation[' + i + '].button'
        this.setData({
          [str1]: text_on_button
        })
      }
    }
  },

  // 弃用 判断用户身份是否合法
  //如果合法返回true，不合法就回到index页面
  // checkRole: function() {
  //   if (wx.getStorageSync('role_number') != 2) {
  //     wx.showModal({
  //       title: '提示',
  //       showCancel: false,
  //       content: '禁止操作，因为您的身份不是员工',
  //       success: function(res) {
  //         wx.switchTab({
  //           url: wx.getStorageSync('old_page')
  //         })
  //       }
  //     })
  //     return false
  //   }
  //   return true
  // },

  //* 输入备注
  bindNoteInput: function(e) {
    var index = e.currentTarget.dataset.number
    //根据number检索数据在operation数组中的位置
    var operations=this.data.operation
    var len =operations.length
    for (var i = 0; i < len; i++) {
      var operation = operations[i]
      if (operation.job_number == index) {
        index = i
        break
      }
    }
    //设置备注
    this.setNote(i, e.detail.value)
  },

  //* 生命周期函数--监听页面加载
  onLoad: function(options) {
    this.setNewButton()
    //切换到"待分配"页
    this.changeTitWXSS(1)
  },

  //* 生命周期函数--监听页面初次渲染完成
  onReady: function() {},

  //* 生命周期函数--监听页面显示
  onShow: function() {
    //判断用户身份是否为管理员
    try {
      var value = wx.getStorageSync('role_number')
      if (value == 3) { //是管理员
        //设置tabBar
        var myTabBar = app.globalData.tabBar
        myTabBar.list[0].active = false
        myTabBar.list[1].active = false
        myTabBar.list[2].active = false
        myTabBar.list[3].active = true
        this.setData({
          tabBar: myTabBar,
          isAdmin: true
        })
      }
    } catch (e) {
      // Do something when catch error
    }
    this.setOperations()


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  // * 用户点击右上角分享
  onShareAppMessage: function() {

  }
})