// pages/input/input.js

var data = require('../../utils/data.js')

Page({

  data: {
    receipt_type: ['类型1', '类型2', '类型3', '类型4'], //订单类型
    index: 0,
    region: ['北京市', '北京市', '东城区'],
    customItem: '全部',
    inputValue1: '',
    inputValue2: '',
    inputValue3: '',
    textAreaValue1: '',
    textAreaValue2: '',
    img_path: "/imgs/image.png",
    isAdmin: false,
  },

  //* 点击图片
  onImage: function() {
    var that = this
    wx.chooseImage({
      count: 1,
      success: function(res) {
        var tempFilePath = res.tempFilePaths[0]
        that.setData({
          img_path: tempFilePath
        })
      }
    })
  },

  //* 点击“提交”按钮
  onConfirm: function() {
    //判断用户身份是否合法
    // if (wx.getStorageSync('role_number') != 1) {
    //   wx.showToast({
    //     title: '提交失败，因为您的身份不是管理员',
    //     icon: 'none',
    //     duration: 1300
    //   })
    //   return
    // }
    var that = this
    if (this.checkValue()) {
      wx.showModal({
        title: '提示',
        content: '是否确认您的填写无误并立刻提交？',
        success: function(res) {
          //用户点击确定
          if (res.confirm) {
            //提交订单
            that.doInput()
          }
        }
      })
    }
  },

  //检查提交的数据是否符合格式(todo)
  checkValue: function() {

    return true
  },

  //提交订单
  doInput: function() {
    var index = data.receipt.length
    var user_id = wx.getStorageSync('user_id')
    var receipt = {
      receipt_number: index + 1, //这个id直接用index代替，前面会少0，应该再写个函数来生成(todo)
      receipt_type: this.data.receipt_type[this.data.index],
      state: '待分配',
      user_id: user_id,
      company_id: '公司的company_id', //todo:从company_manage表中获取数据
      remark: this.data.textAreaValue1,
      img: this.data.img_path,
      name: this.data.inputValue1,
      //todo:这里没有处理客户名称(inputValue2)、客户电话、客户地址这些信息
    }
    //向服务器提交数据(todo)
    //
    //修改data.js文件
    data.receipt[index] = receipt
  },

  //* 输入订单名称
  bindKeyInput1: function(e) {
    this.setData({
      inputValue1: e.detail.value
    })
  },

  //* 输入客户名称
  bindKeyInput2: function(e) {
    this.setData({
      inputValue2: e.detail.value
    })
  },

  //* 输入客户电话
  bindKeyInput2: function(e) {
    this.setData({
      inputValue2: e.detail.value
    })
  },

  //* TextArea失去焦点
  bindTextAreaBlur1: function(e) {
    this.setData({
      textAreaValue1: e.detail.value
    })
  },
  bindTextAreaBlur2: function(e) {
    this.setData({
      textAreaValue2: e.detail.value
    })
  },

  //* 订单类型Picker
  bindPickerChange: function(e) {
    this.setData({
      index: e.detail.value
    })
  },

  //* 客户地址Picker
  bindRegionChange: function(e) {
    this.setData({
      region: e.detail.value
    })
  },

  //判断用户身份是否合法
  //如果合法返回true，不合法就回到index页面
  checkRole: function() {
    if (wx.getStorageSync('role_number') != 1) {
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '禁止操作，因为您的身份不是管理员',
        success: function(res) {
          wx.switchTab({
              url: wx.getStorageSync('old_page')
          })
        }
      })
      return false
    }
    return true
  },

  //* 生命周期函数--监听页面显示
  onShow: function() {
    //判断用户身份是否为管理员
    try {
      var value = wx.getStorageSync('role_number')
      if (value == 3) {//是管理员
        //设置tabBar
        var myTabBar = getApp().globalData.tabBar
        myTabBar.list[0].active = false
        myTabBar.list[1].active = true
        myTabBar.list[2].active = false
        myTabBar.list[3].active = false
        this.setData({
          tabBar: myTabBar,
          isAdmin: true
        })
      }
    } catch (e) {
      // Do something when catch error
    }
  },

  //转发
  onShareAppMessage: function (res) {

  }

})