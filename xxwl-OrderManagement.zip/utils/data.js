var job_table = [ //操作列表，根据不同订单，后台会返回不同的操作列表
  {
    job_type: '类型1',
    job_number: '编号01',
    name: '接单',
    status: '已处理',
    user_id: 'user001',
    user_name: 'user001的昵称',
    time: '2018/07/20 13:07:08',
    note: '这是备注-----------------------------------------',
  },
  {
    job_type: '类型1',
    job_number: '编号02',
    name: '拉物料',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号03',
    name: '裁料',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号04',
    name: '补烫',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号05',
    name: '做衣',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号06',
    name: '钉扣子',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号07',
    name: '大烫',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号08',
    name: '包装',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号09',
    name: '送货',
    status: '未处理',
  },
  {
    job_type: '类型1',
    job_number: '编号10',
    name: '收款',
    status: '未处理',
  }
]

var cif_user2 = [{
    user_id: 'user001',
    user_name: 'user001的用户名',
    pass_word: '',
    role_type: '员工',
    user_nickname: 'ueser001的昵称',
  },

]

var business_bill = [{
    receipt_number: '001',
    receipt_type: '类型1',
    state: '财务收款', //这个state的赋值有讲究：工单列表从前往后数，找到第一个非”已完成“的工单，取其name
    user_id: '客户的user_id',
    company_id: '公司的company_id',
    remark: '备注',
    img: 'http://img5.imgtn.bdimg.com/it/u=2906541843,1492984080&fm=23&gp=0.jpg',
    name: "女装T恤中长款",
  },
  {
    receipt_number: '002',
    receipt_type: '类型1',
    state: '待分配',
    user_id: '客户的user_id',
    company_id: '公司的company_id',
    remark: '备注',
    img: "http://img4.imgtn.bdimg.com/it/u=1004404590,1607956492&fm=23&gp=0.jpg",
    name: "修身款圆领男T恤",
  },
  {
    receipt_number: '003',
    receipt_type: '类型2',
    state: '待分配',
    user_id: '客户的user_id',
    company_id: '公司的company_id',
    remark: '备注',
    img: "http://img4.imgtn.bdimg.com/it/u=3986819380,1610061022&fm=23&gp=0.jpg",
    name: "男运动上衣",
  }
]

module.exports.operation = job_table
module.exports.user = cif_user2
module.exports.receipt = business_bill

/*在需要使用这些模块的文件中，使用 require(path) 将公共代码引入
var data = require('../../utils/data.js')
Page({
  operation: data.operation,
})
require暂时不支持绝对路径
*/